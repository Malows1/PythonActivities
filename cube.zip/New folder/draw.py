import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

def draw_square():
    glBegin(GL_TRIANGLES)
    glVertex3f(-0.5, -0.5, 0.0)
    glVertex3f(0.5, -0.5, 0.0)
    glVertex3f(-0.5, 0.5, 0.0)

    glVertex3f(0.5, -0.5, 0.0)
    glVertex3f(0.5, 0.5, 0.0)
    glVertex3f(-0.5, 0.5, 0.0)
    glEnd()

def draw_cube():
    add_texture()  # Call the function to load and enable the texture

    glBegin(GL_QUADS)
    
    glTexCoord2f(0, 0)
    glVertex3f(-0.5, -0.5, 0.5)  # Front bottom left
    glTexCoord2f(1, 0)
    glVertex3f(0.5, -0.5, 0.5)   # Front bottom right
    glTexCoord2f(1, 1)
    glVertex3f(0.5, 0.5, 0.5)    # Front top right
    glTexCoord2f(0, 1)
    glVertex3f(-0.5, 0.5, 0.5)   # Front top left
    
    glTexCoord2f(0, 0)
    glVertex3f(-0.5, -0.5, -0.5)  # Back bottom left
    glTexCoord2f(1, 0)
    glVertex3f(0.5, -0.5, -0.5)   # Back bottom right
    glTexCoord2f(1, 1)
    glVertex3f(0.5, 0.5, -0.5)    # Back top right
    glTexCoord2f(0, 1)
    glVertex3f(-0.5, 0.5, -0.5)   # Back top left

    glTexCoord2f(0, 0)
    glVertex3f(-0.5, 0.5, 0.5)    # Top front left
    glTexCoord2f(1, 0)
    glVertex3f(0.5, 0.5, 0.5)     # Top front right
    glTexCoord2f(1, 1)
    glVertex3f(0.5, 0.5, -0.5)    # Top back right
    glTexCoord2f(0, 1)
    glVertex3f(-0.5, 0.5, -0.5)   # Top back left
    
    glTexCoord2f(0, 0)
    glVertex3f(-0.5, -0.5, 0.5)   # Bottom front left
    glTexCoord2f(1, 0)
    glVertex3f(0.5, -0.5, 0.5)    # Bottom front right
    glTexCoord2f(1, 1)
    glVertex3f(0.5, -0.5, -0.5)   # Bottom back right
    glTexCoord2f(0, 1)
    glVertex3f(-0.5, -0.5, -0.5)  # Bottom back left

    glTexCoord2f(0, 0)
    glVertex3f(0.5, -0.5, 0.5)    # Right front bottom
    glTexCoord2f(1, 0)
    glVertex3f(0.5, 0.5, 0.5)     # Right front top
    glTexCoord2f(1, 1)
    glVertex3f(0.5, 0.5, -0.5)    # Right back top
    glTexCoord2f(0, 1)
    glVertex3f(0.5, -0.5, -0.5)   # Right back bottom

    glTexCoord2f(0, 0)
    glVertex3f(-0.5, -0.5, 0.5)   # Left front bottom
    glTexCoord2f(1, 0)
    glVertex3f(-0.5, 0.5, 0.5)    # Left front top
    glTexCoord2f(1, 1)
    glVertex3f(-0.5, 0.5, -0.5)   # Left back top
    glTexCoord2f(0, 1)
    glVertex3f(-0.5, -0.5, -0.5)  # Left back bottom

    glEnd()

def add_texture():
    image = pygame.image.load('texture.jpeg')
    data = pygame.image.tostring(image, 'RGBA')
    texID = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, texID)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.get_width(), image.get_height(), 0, GL_RGBA, GL_UNSIGNED_BYTE, data)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glEnable(GL_TEXTURE_2D)

def main():
    pygame.init()
    display = (800, 600)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    glEnable(GL_DEPTH_TEST)
    gluPerspective(45, (display[0] / display[1]), 0.1, 50.0)
    glTranslatef(0.0, 0.0, -5)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        glRotatef(1, 3, 1, 1)  # Rotate the cube for a better view
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        draw_cube()
        pygame.display.flip()
        pygame.time.wait(10)

if __name__ == "__main__":
    main()